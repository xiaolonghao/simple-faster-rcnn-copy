conda env create -f enviroment.yaml
#conda install pytorch==1.0.0 torchvision==0.2.1 cuda90 -c pytorch;
pip install -r requirements.txt
conda install cupy;
conda install 'pillow<7.0.0';
cd model/utils/nms/;
python build.py build_ext --inplace;
cd -;
cd data;
ln -s /path/to/VOCdevkit/VOC2007/ VOC2007;
cd -;
cd misc; 
python convert_caffe_pretrain.py;
cd -
python train.py
nohup python -m visdom.server &
